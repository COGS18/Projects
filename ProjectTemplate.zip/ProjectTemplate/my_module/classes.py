"""Classes used throughout project"""

class Student():
    
    """
    Create an instance for each Student in class
    
    Parameters
    ----------
    name : str
        Student's first name
    sid : str
        Students ID number
    assignments : dictionary
        Grades for each assignment throughout class
    """
    
    def __init__(self, name, sid, assignments):
        self.name = name
        self.sid = sid
        self.assignments = assignments
        
    # add a method