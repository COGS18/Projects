"""Test for my functions.

Note: because these are 'empty' functions (return None), here we just test
  that the functions execute, and return None, as expected.
"""

from functions import my_func, my_other_func, calculate_student_grade
from classes import Student

##
##

def test_my_func():

    assert my_func() == None

def test_my_other_func():

    assert my_other_func() == None
    

def test_calculate_student_grade():
    
    test_student = Student('Shannon', 'A12345678', {'A1' : 7, 'A2' : 6})
    full_grade = calculate_student_grade(test_student)
    
    assert full_grade == 13


                 
    