"""A collection of function for doing my project."""

def my_func():
    pass

def my_other_func():
    pass

def calculate_student_grade(student):
    
    """
    Calculate student's final grade across all assignments
    
    Parameters
    ----------
    student : Student Object
        Object of class Student
    
    Returns
    -------
    total : float
        Total score summed across all assignments
    """
    
    total = 0
    
    for key in student.assignments:
        total += student.assignments[key]
        
    return total
